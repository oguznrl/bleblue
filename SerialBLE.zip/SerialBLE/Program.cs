﻿using nexus.protocols.ble;
using nexus.protocols.ble.scan;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace SerialBLE
{
    static class Program
    {
        /// <summary>
        /// Uygulamanın ana girdi noktası.
        /// </summary>
        [STAThread]
        static void Main()
        {
            IBluetoothLowEnergyAdapter ble = BluetoothLowEnergyAdapter.ObtainDefaultAdapter();
            if (ble.AdapterCanBeEnabled && ble.CurrentState.IsDisabledOrDisabling())
            {
                await nexus.protocols.ble.EnableAdapter();
                nexus.protocols.ble.CurrentState.Value; // e.g.: EnabledDisabledState.Enabled
                                                        // The adapter implements IObservable<EnabledDisabledState> so you can subscribe to its state
                nexus.protocols.ble.CurrentState.Subscribe(state => Debug.WriteLine("New State: {0}", state));


                var cts = new CancellationTokenSource(TimeSpan.FromSeconds(30));

                await ble.ScanForBroadcasts(
                    new ScanSettings()
                    {
                        // Setting the scan mode is currently only applicable to Android and has no effect on other platforms.
                        // If not provided, defaults to ScanMode.Balanced
                        Mode = ScanMode.LowPower,

                        // Optional scan filter to ensure that the observer will only receive peripherals
                        // that pass the filter. If you want to scan for everything around, omit the filter.
                        Filter = new ScanFilter()
                        {
                            AdvertisedDeviceName = "foobar",
                            AdvertisedManufacturerCompanyId = 76,
                            // peripherals must advertise at-least-one of any GUIDs in this list
                            AdvertisedServiceIsInList = new List<Guid>() { someGuid },
                        },

                        // ignore repeated advertisements from the same device during this scan
                        IgnoreRepeatBroadcasts = false
                    },




                    );

                // Your IObserver<IBlePeripheral> or Action<IBlePeripheral> will be triggered for each discovered
                // peripheral based on the provided scan settings and filter (if any).
                (IBlePeripheral peripheral) =>
                {
                    // read the advertising data
                    var adv = peripheral.Advertisement;
                    Debug.WriteLine(adv.DeviceName);
                    Debug.WriteLine(adv.Services.Select(x => x.ToString()).Join(","));
                    Debug.WriteLine(adv.ManufacturerSpecificData.FirstOrDefault().CompanyName());
                    Debug.WriteLine(adv.ServiceData);

                    // if we found what we needed, stop the scan manually
                    cts.Cancel();

                    // perhaps connect to the device (see next example)...
                },
   // Provide a CancellationToken to stop the scan, or use the overload that takes a TimeSpan.
   // If you omit this argument, the scan will timeout after BluetoothLowEnergyUtils.DefaultScanTimeout
   cts.Token
  );

                // scanning has stopped when code reached this point since the scan was awaited

            }


            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());

        }
    }
}
